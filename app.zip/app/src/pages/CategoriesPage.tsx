import { ChevronLeft } from 'lucide-react'
import { mainCategories, sectionsByCategory } from '@/data/content'
import type { Section } from '@/data/content'

interface Props {
  onOpenSection: (s: Section) => void
}

export default function CategoriesPage({ onOpenSection }: Props) {
  return (
    <div className="px-4 pt-5 pb-4 space-y-6">
      <div>
        <h2 className="font-black text-xl">كل الأقسام</h2>
        <p className="text-xs text-[hsl(var(--muted-foreground))] mt-1">13 قسماً رئيسياً و45 قسماً فرعياً تغطي كل احتياجاتك</p>
      </div>

      {mainCategories.map((c) => {
        const Icon = c.icon
        const subs = sectionsByCategory(c.id)
        return (
          <section key={c.id} className="animate-fade-up">
            <div className="flex items-center gap-2 mb-2.5">
              <span className={`w-8 h-8 rounded-xl ${c.color} grid place-items-center`}>
                <Icon className={`w-4.5 h-4.5 ${c.textColor}`} />
              </span>
              <h3 className="font-black text-sm">{c.name}</h3>
              <span className="text-[10px] text-[hsl(var(--muted-foreground))]">({subs.length})</span>
            </div>
            <div className="bg-white rounded-2xl border border-[hsl(var(--border))] divide-y divide-[hsl(var(--border))]">
              {subs.map((s) => {
                const SIcon = s.icon
                return (
                  <button
                    key={s.id}
                    onClick={() => onOpenSection(s)}
                    className="w-full flex items-center gap-3 px-4 py-3 text-right"
                  >
                    <SIcon className="w-5 h-5 text-[hsl(var(--primary))] shrink-0" />
                    <span className="flex-1 font-bold text-sm">{s.name}</span>
                    <ChevronLeft className="w-4 h-4 text-slate-300" />
                  </button>
                )
              })}
            </div>
          </section>
        )
      })}
    </div>
  )
}
