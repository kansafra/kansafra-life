import { User, Package, Heart, MessageSquareWarning, Settings, Globe, LogIn, ChevronLeft, Store } from 'lucide-react'

const menu = [
  { icon: Package, label: 'طلباتي وحجوزاتي', hint: 'تابع حالة طلباتك' },
  { icon: Store, label: 'متجري', hint: 'أضف منتجاتك وأدر متجرك' },
  { icon: Heart, label: 'المفضلة', hint: 'المحلات والمنتجات المحفوظة' },
  { icon: MessageSquareWarning, label: 'شكاواي ومقترحاتي', hint: 'تابع حالة الشكاوى' },
  { icon: Globe, label: 'اللغة', hint: 'العربية — English — Türkçe' },
  { icon: Settings, label: 'الإعدادات', hint: 'الإشعارات والخصوصية' },
]

export default function ProfilePage() {
  return (
    <div className="px-4 pt-5 pb-4 space-y-5">
      <div className="bg-gradient-to-l from-[#0a7c59] to-[#063f30] rounded-3xl p-5 text-white flex items-center gap-4">
        <span className="w-16 h-16 rounded-full bg-white/15 border-2 border-white/30 grid place-items-center shrink-0">
          <User className="w-8 h-8" />
        </span>
        <div className="flex-1">
          <h2 className="font-black text-lg">أهلاً بك في كنصفرة لايف</h2>
          <p className="text-xs text-emerald-100/80 mt-0.5">سجّل دخولك لإدارة طلباتك ومتجرك</p>
        </div>
      </div>

      <button className="w-full h-12 rounded-2xl bg-[hsl(var(--primary))] text-white font-black text-sm flex items-center justify-center gap-2">
        <LogIn className="w-4.5 h-4.5" />
        تسجيل الدخول / إنشاء حساب
      </button>

      <div className="bg-white rounded-2xl border border-[hsl(var(--border))] divide-y divide-[hsl(var(--border))]">
        {menu.map((m) => {
          const Icon = m.icon
          return (
            <button key={m.label} className="w-full flex items-center gap-3 px-4 py-3.5 text-right">
              <span className="w-9 h-9 rounded-xl bg-[hsl(var(--secondary))] grid place-items-center shrink-0">
                <Icon className="w-4.5 h-4.5 text-[hsl(var(--primary))]" />
              </span>
              <span className="flex-1">
                <span className="block font-bold text-sm">{m.label}</span>
                <span className="block text-[11px] text-[hsl(var(--muted-foreground))] mt-0.5">{m.hint}</span>
              </span>
              <ChevronLeft className="w-4 h-4 text-slate-300" />
            </button>
          )
        })}
      </div>

      <p className="text-center text-[11px] text-[hsl(var(--muted-foreground))] leading-5">
        كنصفرة لايف — الإصدار 1.0<br />إدلب — سوريا
      </p>
    </div>
  )
}
