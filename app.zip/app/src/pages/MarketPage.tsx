import { useState } from 'react'
import { BadgeCheck, ShoppingCart, Store, Recycle, RefreshCcw, Gavel } from 'lucide-react'
import { products } from '@/data/content'

interface Props {
  onAddToCart: (id: number) => void
}

const tabs = [
  { id: 'all', label: 'الكل', icon: Store },
  { id: 'used', label: 'مستعمل', icon: Recycle },
  { id: 'barter', label: 'مقايضة', icon: RefreshCcw },
  { id: 'auction', label: 'مزادات', icon: Gavel },
]

export default function MarketPage({ onAddToCart }: Props) {
  const [tab, setTab] = useState('all')

  return (
    <div className="px-4 pt-5 pb-4 space-y-4">
      <div>
        <h2 className="font-black text-xl">السوق التجاري</h2>
        <p className="text-xs text-[hsl(var(--muted-foreground))] mt-1">منتجات محلات كنصفرة — دفع عند الاستلام أو تحويل محلي</p>
      </div>

      <div className="flex gap-2 overflow-x-auto no-scrollbar">
        {tabs.map((t) => {
          const Icon = t.icon
          const active = tab === t.id
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold border transition-colors ${
                active
                  ? 'bg-[hsl(var(--primary))] text-white border-[hsl(var(--primary))]'
                  : 'bg-white border-[hsl(var(--border))] text-[hsl(var(--muted-foreground))]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {t.label}
            </button>
          )
        })}
      </div>

      {tab !== 'all' ? (
        <div className="bg-white border border-dashed border-[hsl(var(--border))] rounded-2xl p-8 text-center">
          <p className="font-bold text-sm">قسم «{tabs.find((t) => t.id === tab)?.label}»</p>
          <p className="text-xs text-[hsl(var(--muted-foreground))] mt-1">قريباً في النسخة القادمة — جرب تبويب «الكل» الآن</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {products.map((p, i) => {
            const Icon = p.icon
            return (
              <div
                key={p.id}
                className="bg-white rounded-2xl border border-[hsl(var(--border))] overflow-hidden animate-fade-up"
                style={{ animationDelay: `${i * 40}ms` }}
              >
                <div className={`h-28 bg-gradient-to-br ${p.color} grid place-items-center relative`}>
                  <Icon className="w-12 h-12 text-white/90" />
                  {p.offer && (
                    <span className="absolute top-2 right-2 bg-white/95 text-[10px] font-black px-2 py-0.5 rounded-full text-[#17203c]">
                      {p.offer}
                    </span>
                  )}
                </div>
                <div className="p-3">
                  <p className="font-bold text-sm truncate">{p.name}</p>
                  <p className="text-[11px] text-[hsl(var(--muted-foreground))] flex items-center gap-1 mt-0.5">
                    {p.shop} {p.verified && <BadgeCheck className="w-3.5 h-3.5 text-[hsl(var(--primary))]" />}
                  </p>
                  <div className="flex items-center justify-between mt-2.5">
                    <div className="flex items-baseline gap-1">
                      <span className="font-black text-base text-[hsl(var(--primary))]">{p.price}</span>
                      {p.oldPrice && <span className="text-[10px] line-through text-slate-400">{p.oldPrice}</span>}
                    </div>
                    <button
                      onClick={() => onAddToCart(p.id)}
                      className="h-8 px-3 rounded-full bg-[hsl(var(--primary))] text-white text-[11px] font-bold flex items-center gap-1"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                      أضف
                    </button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
