import { useState } from 'react'
import { Phone, Droplets, MapPin, CheckCircle2 } from 'lucide-react'
import { emergencyNumbers, bloodRequests } from '@/data/content'

export default function EmergencyPage() {
  const [sosSent, setSosSent] = useState(false)

  return (
    <div className="px-4 pt-5 pb-4 space-y-6">
      <div className="text-center">
        <h2 className="font-black text-xl">الطوارئ</h2>
        <p className="text-xs text-[hsl(var(--muted-foreground))] mt-1">مساعدة فورية عند الطارئ — إشعار الجيران والجهات المختصة</p>
      </div>

      {/* زر SOS */}
      <div className="flex flex-col items-center py-4">
        <button
          onClick={() => setSosSent(true)}
          className="w-40 h-40 rounded-full bg-gradient-to-b from-red-500 to-red-700 text-white shadow-2xl animate-sos grid place-items-center active:scale-95 transition-transform"
          aria-label="زر الخطر SOS"
        >
          <span className="text-center">
            <span className="block font-black text-4xl tracking-widest">SOS</span>
            <span className="block text-[11px] mt-1 text-red-100">اضغط عند الخطر</span>
          </span>
        </button>
        {sosSent && (
          <div className="mt-4 bg-emerald-50 border border-emerald-200 rounded-2xl px-4 py-3 flex items-center gap-2 animate-fade-up">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <p className="text-xs font-bold text-emerald-700">تم إرسال موقعك ونداء الاستغاثة للجهات المختصة (عرض تجريبي)</p>
          </div>
        )}
        <p className="flex items-center gap-1 text-[11px] text-[hsl(var(--muted-foreground))] mt-4">
          <MapPin className="w-3.5 h-3.5" /> يتم إرفاق موقعك الحالي تلقائياً مع النداء
        </p>
      </div>

      {/* أرقام الطوارئ */}
      <section>
        <h3 className="font-black text-base mb-3">أرقام الطوارئ</h3>
        <div className="grid grid-cols-2 gap-3">
          {emergencyNumbers.map((n) => {
            const Icon = n.icon
            return (
              <a
                key={n.name}
                href={`tel:${n.number.replace(/\s/g, '')}`}
                className="bg-white rounded-2xl border border-[hsl(var(--border))] p-4 flex items-center gap-3"
              >
                <span className={`w-10 h-10 rounded-xl ${n.color} grid place-items-center shrink-0`}>
                  <Icon className="w-5 h-5 text-white" />
                </span>
                <div>
                  <p className="font-bold text-xs">{n.name}</p>
                  <p className="text-xs text-[hsl(var(--muted-foreground))] font-mono mt-0.5" dir="ltr">{n.number}</p>
                </div>
              </a>
            )
          })}
        </div>
      </section>

      {/* طلبات الدم العاجلة */}
      <section>
        <h3 className="font-black text-base mb-3">طلبات دم عاجلة</h3>
        <div className="space-y-2.5">
          {bloodRequests.map((b, i) => (
            <div key={i} className="bg-white rounded-2xl border border-[hsl(var(--border))] p-4 flex items-center gap-3">
              <span className={`w-12 h-12 rounded-full grid place-items-center font-black text-sm shrink-0 ${
                b.urgent ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-600'
              }`}>
                {b.blood}
              </span>
              <div className="flex-1">
                <p className="font-bold text-sm flex items-center gap-1.5">
                  زمرة {b.blood}
                  {b.urgent && <span className="text-[9px] font-black px-1.5 py-0.5 rounded bg-red-500 text-white">عاجل</span>}
                </p>
                <p className="text-[11px] text-[hsl(var(--muted-foreground))] mt-0.5">{b.place} — {b.when}</p>
              </div>
              <button className="shrink-0 h-9 px-3.5 rounded-full bg-red-600 text-white text-[11px] font-bold flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5" />
                أتبرع
              </button>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-sky-50 border border-sky-200 rounded-2xl p-4">
        <h4 className="font-black text-sm text-sky-800 mb-1">إشعار الجيران</h4>
        <p className="text-xs text-sky-700 leading-5">
          عند تفعيل زر الخطر، يصل تنبيه فوري للجيران المسجلين ضمن نطاق 500 متر لطلب المساعدة العاجلة.
        </p>
        <button className="mt-3 h-9 px-4 rounded-full bg-sky-600 text-white text-xs font-bold flex items-center gap-1.5">
          <Phone className="w-3.5 h-3.5" />
          تفعيل إشعار الجيران
        </button>
      </section>
    </div>
  )
}
