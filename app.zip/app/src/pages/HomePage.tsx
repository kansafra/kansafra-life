import { Search, Megaphone, ChevronLeft, BadgeCheck, ShoppingCart, Droplets } from 'lucide-react'
import { mainCategories, sectionsByCategory, products, infoItems, announcements, bloodRequests } from '@/data/content'
import type { Section } from '@/data/content'
import type { PageId } from '@/types'

interface Props {
  onOpenSection: (s: Section) => void
  onNavigate: (p: PageId) => void
  onAddToCart: (id: number) => void
}

export default function HomePage({ onOpenSection, onNavigate, onAddToCart }: Props) {
  return (
    <div className="space-y-6 pb-4">
      {/* البحث */}
      <div className="px-4 pt-4">
        <div className="flex items-center gap-2 bg-white border border-[hsl(var(--border))] rounded-2xl px-4 py-3 shadow-sm">
          <Search className="w-5 h-5 text-slate-400" />
          <input
            placeholder="ابحث عن محل، خدمة، منتج، طبيب..."
            className="flex-1 bg-transparent outline-none text-sm placeholder:text-slate-400"
          />
        </div>
      </div>

      {/* شريط معلومات اليوم */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar px-4">
        {infoItems.map((it) => (
          <div key={it.label} className="shrink-0 bg-white border border-[hsl(var(--border))] rounded-xl px-3.5 py-2 text-center">
            <p className="text-[10px] text-[hsl(var(--muted-foreground))]">{it.label}</p>
            <p className="text-xs font-bold mt-0.5 whitespace-nowrap">{it.value}</p>
          </div>
        ))}
      </div>

      {/* شريط الإعلانات */}
      <div className="mx-4 bg-[hsl(var(--primary))]/8 border border-[hsl(var(--primary))]/15 rounded-2xl px-3 py-2.5 flex items-center gap-2 overflow-hidden">
        <Megaphone className="w-4 h-4 text-[hsl(var(--primary))] shrink-0" />
        <div className="overflow-hidden flex-1">
          <p className="text-xs font-medium whitespace-nowrap animate-ticker inline-block">
            {announcements.join('   •   ')}
          </p>
        </div>
      </div>

      {/* بانر ترحيبي */}
      <div className="px-4">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-l from-[#0a7c59] to-[#063f30] text-white p-5">
          <div className="absolute -left-6 -top-10 w-36 h-36 rounded-full bg-white/5" />
          <div className="absolute left-10 bottom-0 w-20 h-20 rounded-full bg-[#e5a52e]/20" />
          <p className="text-[11px] text-emerald-100/80 font-medium">منصة الحياة الكاملة</p>
          <h2 className="font-black text-xl mt-1 leading-8">كل ما تحتاجه في بلدتك<br />بضغطة زر واحدة</h2>
          <button
            onClick={() => onNavigate('market')}
            className="mt-3 bg-[#e5a52e] text-[#17203c] text-xs font-black px-4 py-2 rounded-full inline-flex items-center gap-1"
          >
            تسوّق الآن
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* الأقسام الرئيسية */}
      <section className="px-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-black text-base">الأقسام الرئيسية</h3>
          <button onClick={() => onNavigate('categories')} className="text-xs font-bold text-[hsl(var(--primary))] flex items-center">
            الكل <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="grid grid-cols-4 gap-3">
          {mainCategories.map((c, i) => {
            const Icon = c.icon
            return (
              <button
                key={c.id}
                onClick={() => onOpenSection(sectionsByCategory(c.id)[0])}
                className="flex flex-col items-center gap-1.5 animate-fade-up"
                style={{ animationDelay: `${i * 30}ms` }}
              >
                <span className={`w-14 h-14 rounded-2xl ${c.color} grid place-items-center shadow-sm`}>
                  <Icon className={`w-6 h-6 ${c.textColor}`} />
                </span>
                <span className="text-[10.5px] font-bold text-center leading-3.5">{c.name}</span>
              </button>
            )
          })}
        </div>
      </section>

      {/* تنبيه دم عاجل */}
      <section className="px-4">
        <button
          onClick={() => onNavigate('emergency')}
          className="w-full bg-red-50 border border-red-200 rounded-2xl p-4 flex items-center gap-3 text-right"
        >
          <span className="w-11 h-11 rounded-full bg-red-500 grid place-items-center shrink-0 animate-pulse">
            <Droplets className="w-5 h-5 text-white" />
          </span>
          <div className="flex-1">
            <p className="font-black text-sm text-red-700">مطلوب دم {bloodRequests[0].blood} بشكل عاجل</p>
            <p className="text-xs text-red-500 mt-0.5">{bloodRequests[0].place} — {bloodRequests[0].when}</p>
          </div>
          <ChevronLeft className="w-5 h-5 text-red-400" />
        </button>
      </section>

      {/* عروض السوق */}
      <section>
        <div className="flex items-center justify-between px-4 mb-3">
          <h3 className="font-black text-base">عروض السوق</h3>
          <button onClick={() => onNavigate('market')} className="text-xs font-bold text-[hsl(var(--primary))] flex items-center">
            السوق <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="flex gap-3 overflow-x-auto no-scrollbar px-4">
          {products.slice(0, 6).map((p) => {
            const Icon = p.icon
            return (
              <div key={p.id} className="shrink-0 w-40 bg-white rounded-2xl border border-[hsl(var(--border))] overflow-hidden">
                <div className={`h-24 bg-gradient-to-br ${p.color} grid place-items-center relative`}>
                  <Icon className="w-10 h-10 text-white/90" />
                  {p.offer && (
                    <span className="absolute top-2 right-2 bg-white/95 text-[10px] font-black px-2 py-0.5 rounded-full text-[#17203c]">
                      {p.offer}
                    </span>
                  )}
                </div>
                <div className="p-3">
                  <p className="font-bold text-xs truncate">{p.name}</p>
                  <p className="text-[10px] text-[hsl(var(--muted-foreground))] flex items-center gap-1 mt-0.5">
                    {p.shop} {p.verified && <BadgeCheck className="w-3 h-3 text-[hsl(var(--primary))]" />}
                  </p>
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-baseline gap-1">
                      <span className="font-black text-sm text-[hsl(var(--primary))]">{p.price}</span>
                      {p.oldPrice && <span className="text-[10px] line-through text-slate-400">{p.oldPrice}</span>}
                    </div>
                    <button
                      onClick={() => onAddToCart(p.id)}
                      className="w-7 h-7 rounded-full bg-[hsl(var(--primary))] text-white grid place-items-center"
                      aria-label="أضف للسلة"
                    >
                      <ShoppingCart className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </section>
    </div>
  )
}
