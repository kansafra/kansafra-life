import {
  Store, Recycle, RefreshCcw, Gavel, Gift, KeyRound, UtensilsCrossed, Hammer, Package, Building2,
  HeartPulse, Droplets, Pill, Landmark, GraduationCap, BookOpenCheck, FileText, Moon, CalendarDays,
  Sparkles, Briefcase, Laptop, CarFront, Users2, Tractor, Wrench, Home, Baby, PersonStanding, PawPrint,
  PartyPopper, Cake, Mail, Heart, Wallet, CircleDollarSign, Siren, Ambulance, LifeBuoy, MessageSquareWarning,
  HandHeart, Newspaper, CloudSun, Trophy, type LucideIcon,
} from 'lucide-react'

/* ---------- الأنواع ---------- */
export interface MainCategory {
  id: string
  name: string
  nameEn: string
  icon: LucideIcon
  color: string       // لون خلفية الأيقونة
  textColor: string
}

export interface Listing {
  name: string
  detail: string
  phone: string
  verified?: boolean
  tag?: string
}

export interface Section {
  id: string
  categoryId: string
  name: string
  icon: LucideIcon
  desc: string
  listings: Listing[]
}

export interface Product {
  id: number
  name: string
  shop: string
  price: string
  oldPrice?: string
  icon: LucideIcon
  color: string
  verified?: boolean
  offer?: string
}

/* ---------- الأقسام الرئيسية (13) ---------- */
export const mainCategories: MainCategory[] = [
  { id: 'commerce',   name: 'التجارة',           nameEn: 'Commerce',    icon: Store,          color: 'bg-emerald-100', textColor: 'text-emerald-700' },
  { id: 'health',     name: 'الصحة والطاب',       nameEn: 'Health',      icon: HeartPulse,     color: 'bg-rose-100',    textColor: 'text-rose-600' },
  { id: 'government', name: 'الخدمات الحكومية',   nameEn: 'Government',  icon: Landmark,       color: 'bg-sky-100',     textColor: 'text-sky-700' },
  { id: 'education',  name: 'التعليم',           nameEn: 'Education',   icon: GraduationCap,  color: 'bg-indigo-100', textColor: 'text-indigo-600' },
  { id: 'religion',   name: 'الدين والمساجد',     nameEn: 'Religious',   icon: Moon,           color: 'bg-teal-100',   textColor: 'text-teal-700' },
  { id: 'jobs',       name: 'الأعمال والوظائف',   nameEn: 'Jobs',        icon: Briefcase,      color: 'bg-amber-100',  textColor: 'text-amber-700' },
  { id: 'transport',  name: 'النقل',             nameEn: 'Transport',   icon: CarFront,       color: 'bg-cyan-100',   textColor: 'text-cyan-700' },
  { id: 'agri',       name: 'الزراعة',           nameEn: 'Agriculture', icon: Tractor,        color: 'bg-lime-100',   textColor: 'text-lime-700' },
  { id: 'services',   name: 'الخدمات',           nameEn: 'Services',    icon: Wrench,         color: 'bg-orange-100', textColor: 'text-orange-600' },
  { id: 'events',     name: 'المناسبات',         nameEn: 'Events',      icon: PartyPopper,    color: 'bg-fuchsia-100',textColor: 'text-fuchsia-600' },
  { id: 'finance',    name: 'المالية',           nameEn: 'Finance',     icon: Wallet,         color: 'bg-violet-100', textColor: 'text-violet-600' },
  { id: 'community',  name: 'الطوارئ والمجتمع',   nameEn: 'Community',   icon: Siren,          color: 'bg-red-100',    textColor: 'text-red-600' },
  { id: 'info',       name: 'المعلومات والترفيه', nameEn: 'Info & Fun',  icon: Newspaper,      color: 'bg-slate-200',  textColor: 'text-slate-600' },
]

/* ---------- الأقسام الفرعية (45) ---------- */
const ph = '0930 000 000'
export const sections: Section[] = [
  // التجارة
  { id: 'market', categoryId: 'commerce', name: 'السوق التجاري', icon: Store, desc: 'كل محلات كنصفرة: ألبسة، أحذية، إلكترونيات، أجهزة منزلية، عطور، مواد بناء، بقالة، خضار وفواكه، ذهب ومجوهرات وأكثر.',
    listings: [
      { name: 'محل الأمانة للألبسة الرجالية', detail: 'ألبسة رجالية وأحذية — الشارع الرئيسي', phone: '0930 111 223', verified: true, tag: 'موثوق' },
      { name: 'بقالة البركة', detail: 'مواد غذائية ومنظفات — حي الجامع', phone: '0938 445 667', verified: true },
      { name: 'مكتبة المعرفة', detail: 'قرطاسية وكتب ومستلزمات دراسية', phone: '0944 778 899' },
      { name: 'محلات نور للأجهزة المنزلية', detail: 'أجهزة كهربائية ومنزلية مع كفالة', phone: '0955 222 110', verified: true },
    ] },
  { id: 'used', categoryId: 'commerce', name: 'سوق المستعمل', icon: Recycle, desc: 'هواتف وإلكترونيات مستعملة، أثاث وأجهزة منزلية، سيارات ودراجات، ألبسة وأحذية بحالة جيدة.',
    listings: [
      { name: 'هاتف Samsung A52 مستعمل', detail: 'حالة ممتازة مع كافة الملحقات — 95$', phone: ph, tag: 'عرض جديد' },
      { name: 'غرفة نوم مستعملة', detail: 'خشب زان بحالة جيدة جداً', phone: ph },
    ] },
  { id: 'barter', categoryId: 'commerce', name: 'المقايضة والتبادل', icon: RefreshCcw, desc: 'تبادل السلع بدون نقد — قدّم عرضك وانتظر القبول أو الرفض.',
    listings: [{ name: 'دراجة هوائية مقابل هاتف', detail: 'دراجة بحالة جيدة مقابل هاتف متوسط', phone: ph, tag: 'مقايضة' }] },
  { id: 'auction', categoryId: 'commerce', name: 'المزادات', icon: Gavel, desc: 'مزايدة على منتجات معينة بعداد تنازلي، والأعلى مزايدة يفوز مع إشعارات فورية.',
    listings: [{ name: 'مزاد: مولدة كهربائية 5 كيلو', detail: 'ينتهي بعد يومين — أعلى مزايدة 320$', phone: ph, tag: 'مزاد نشط' }] },
  { id: 'donate', categoryId: 'commerce', name: 'الإهداء والتبرع', icon: Gift, desc: '«أهدي بيدي» أشياء مجانية، و«أتبرع بيدي» لخدمة الفقراء والفئات المحتاجة.',
    listings: [{ name: 'ملابس أطفال للإهداء', detail: 'عمر 2-5 سنوات، نظيفة ومرتبة', phone: ph, tag: 'إهداء' }] },
  { id: 'rent', categoryId: 'commerce', name: 'التأجير', icon: KeyRound, desc: 'فساتين أعراس، بدلات رجالية، كاميرات، معدات بناء، سيارات، لوازم حفلات، غرف وأجنحة.',
    listings: [{ name: 'تأجير فساتين سهرة وأعراس', detail: 'موديلات حديثة بأسعار مناسبة', phone: '0940 332 211', verified: true }] },
  { id: 'homefood', categoryId: 'commerce', name: 'الأكل المنزلي', icon: UtensilsCrossed, desc: 'نساء يطبخن أكل بيتي: وجبات بالطلب، حلويات منزلية، مخللات ومشروبات طبيعية.',
    listings: [
      { name: 'أم أحمد للأكل البيتي', detail: 'كبة، محاشي، يبرق — طلب مسبق بيوم', phone: '0955 667 788', verified: true, tag: 'الأكثر طلباً' },
      { name: 'حلويات أم محمد', detail: 'كنافة ومعمول وقطر بحشوات فاخرة', phone: '0933 908 070' },
    ] },
  { id: 'crafts', categoryId: 'commerce', name: 'الحرف اليدوية', icon: Hammer, desc: 'منتجات يدوية: تطريز، صوف، خشب، نحاس، فخار، سجاد، إكسسوارات، لوحات فنية.',
    listings: [{ name: 'ورشة الفن اليدوي', detail: 'تطريز ولوحات وهدايا مخصصة', phone: ph }] },
  { id: 'gifts', categoryId: 'commerce', name: 'الهدايا المخصصة', icon: Package, desc: 'تغليف هدايا، بطاقات مخصصة، باقات ورد، كيك مخصص، توصيل الهدية مع رسالة.',
    listings: [{ name: 'متجر لمسة للهدايا', detail: 'تغليف أنيق وتوصيل داخل البلدة', phone: '0941 556 677', verified: true }] },
  { id: 'realestate', categoryId: 'commerce', name: 'العقارات والإسكان', icon: Building2, desc: 'بيع وإيجار منازل، أراضٍ ومحلات ومستودعات، مكاتب عقارية، مقاولو بناء، خدمات تبييض وتشطيب.',
    listings: [
      { name: 'مكتب كنصفرة العقاري', detail: 'بيع وإيجار منازل وأراضٍ', phone: '0930 654 321', verified: true },
      { name: 'منزل للإيجار — حي المدرسة', detail: '3 غرف وصالون، ماء وكهرباء', phone: ph, tag: 'جديد' },
    ] },
  // الصحة
  { id: 'doctors', categoryId: 'health', name: 'الطاب والصحة', icon: HeartPulse, desc: 'عيادات (عيون، جلدية، باطنة، قلب، أسنان، أطفال)، صيدليات، مخابر تحليل، مراكز أشعة ولقاح، أطباء نفسيون ومعالجون فيزيائيون، مستشفيات ومشافٍ.',
    listings: [
      { name: 'د. سامر الحسين — باطنية', detail: 'عيادة قلبية وباطنية — وسط البلد', phone: '0938 112 233', verified: true, tag: 'موثوق' },
      { name: 'صيدلية الشفاء', detail: 'خدمة 24 ساعة — توصيل منزلي', phone: '0944 556 677', verified: true },
      { name: 'مخبر النور للتحاليل', detail: 'تحاليل شاملة ونتائج سريعة', phone: ph },
      { name: 'د. رنا العلي — أسنان', detail: 'تقويم وحشوات وتنظيف', phone: '0956 443 322' },
    ] },
  { id: 'blood', categoryId: 'health', name: 'التبرع بالدم', icon: Droplets, desc: 'بنك معلومات للمتبرعين، طلبات دم عاجلة، إشعار فوري عند الحاجة، شهادات شكر للمتبرعين.',
    listings: [{ name: 'مطلوب دم زمرة O+ بشكل عاجل', detail: 'مشفى إدلب — حالة ولادة طارئة', phone: '0955 100 200', tag: 'عاجل' }] },
  { id: 'urgentmed', categoryId: 'health', name: 'الأدوية العاجلة', icon: Pill, desc: '«بحاجة دواء عاجل»، البحث عن دواء نادر، تبادل بين الصيدليات، توصيل عاجل، تحذير من أدوية منتهية.',
    listings: [{ name: 'مطلوب: إنسولين Lantus', detail: 'حاجة عاجل لمريض سكري', phone: ph, tag: 'عاجل' }] },
  // الحكومة
  { id: 'gov', categoryId: 'government', name: 'الخدمات الحكومية', icon: Landmark, desc: 'الشؤون المدنية (سجل، هوية، إخراج قيد، معاملات وأوراق)، المجلس المحلي، الشؤون الزراعية والاجتماعية، العدل والمحكمة، المالية والجباية، البريد، المختارون، النقابات المهنية، الأعمال، السجل البلدي.',
    listings: [
      { name: 'المجلس المحلي — كنصفرة', detail: 'معاملات وتسجيل وخدمات البلدة', phone: '0930 400 500', verified: true },
      { name: 'الشؤون المدنية', detail: 'هوية وإخراج قيد وسجل', phone: ph },
      { name: 'مكتب البريد', detail: 'طرود ورسائل وحوالات', phone: ph },
    ] },
  // التعليم
  { id: 'schools', categoryId: 'education', name: 'التعليم', icon: GraduationCap, desc: 'مدارس ابتدائية وإعدادية وثانوية، رياض أطفال، معاهد مهنية، جامعات، دورات تقوية، دروس خصوصية، مراكز تحفيظ قرآن، مكتبات تعليمية.',
    listings: [
      { name: 'مدرسة كنصفرة الابتدائية', detail: 'تسجيل ودوام ومتابعة', phone: ph, verified: true },
      { name: 'أ. محمد العلي — رياضيات', detail: 'دروس خصوصية إعدادي وثانوي', phone: '0933 221 144', tag: 'خصوصي' },
    ] },
  { id: 'training', categoryId: 'education', name: 'التدريب والتطوير', icon: BookOpenCheck, desc: 'دورات مهنية، لغات، حاسوب، دورات حرفية، دورات زراعية، دورات تعليمية.',
    listings: [{ name: 'دورة حاسوب ICDL', detail: 'معهد المستقبل — تبدأ الأسبوع القادم', phone: ph, tag: 'دورة' }] },
  { id: 'academic', categoryId: 'education', name: 'الخدمات الأكاديمية', icon: FileText, desc: 'كتابة أبحاث، ترجمة، تدقيق لغوي، تصميم عروض، مشاريع تخرج، تدريب على المقابلات.',
    listings: [{ name: 'خدمات الطالب الجامعي', detail: 'أبحاث وترجمة وتصميم عروض', phone: ph }] },
  // الدين
  { id: 'mosques', categoryId: 'religion', name: 'المساجد', icon: Moon, desc: 'معلومات المساجد، الإمام والخطيب والمؤذن، أوقات الصلاة والإقامة، صلاة الجمعة، الدروس الأسبوعية والنسائية، دروس أطفال، إفطارات رمضان، اعتكاف وتراويح، خدمات تحفيظ القرآن.',
    listings: [
      { name: 'جامع كنصفرة الكبير', detail: 'دروس أسبوعية وتحفيظ قرآن', phone: ph, verified: true },
      { name: 'مسجد النور', detail: 'دروس نسائية وأطفال', phone: ph },
    ] },
  { id: 'occasions', categoryId: 'religion', name: 'المناسبات الدينية', icon: CalendarDays, desc: 'إمساكية رمضان كاملة بعداد تنازلي، جدول التراويح والإفطارات الجماعية، زكاة الفطر، سنن العيد وصلاة العيد والتهاني، الأضاحي وتوزيع اللحوم، تذكيرات تلقائية قبل كل مناسبة.',
    listings: [{ name: 'إمساكية رمضان 1447', detail: 'أوقات الإمساك والإفطار حسب كنصفرة', phone: ph, tag: 'إمساكية' }] },
  { id: 'quran', categoryId: 'religion', name: 'دورات القرآن', icon: Sparkles, desc: 'حفظ كامل، قراءة صحيحة، تجويد، تفسير، نورانية للأطفال، حفظ سريع، حلقات صيفية، مسابقات قرآنية، تسجيل إلكتروني وشهادة إتمام.',
    listings: [{ name: 'دورة تجويد القرآن', detail: 'للرجال والنساء — تسجيل إلكتروني', phone: ph, tag: 'تسجيل مفتوح' }] },
  // الأعمال
  { id: 'jobs', categoryId: 'jobs', name: 'الأعمال والوظائف', icon: Briefcase, desc: 'وظائف شاغرة، عروض عمل، باحثون عن عمل، مكاتب تشغيل، شركات ومصانع، ورشات حرفية، مشاريع صغيرة، تدريب مهني.',
    listings: [
      { name: 'مطلوب خياط/ة', detail: 'معمل خياطة — دوام كامل', phone: '0956 778 899', tag: 'وظيفة' },
      { name: 'مطلوب سائق توصيل', detail: 'رخصة عمومي — راتب مجزٍ', phone: ph },
    ] },
  { id: 'freelance', categoryId: 'jobs', name: 'العمل الحر', icon: Laptop, desc: 'تصميم غرافيك ومواقع، تطوير وبرمجيات، كتابة محتوى، ترجمة، تسويق رقمي، تصوير ومونتاج فيديو، إدارة سوشال ميديا.',
    listings: [{ name: 'مصمم غرافيك — عن بُعد', detail: 'شعارات وهوية بصرية وإعلانات', phone: ph, tag: 'عن بُعد' }] },
  // النقل
  { id: 'transport', categoryId: 'transport', name: 'المواصلات والنقل', icon: CarFront, desc: 'تكاسي، باصات وسيرفيس، نقل بضائع، شحن، تأجير سيارات، محطات وقود، ورشات صيانة، قطع غيار، غسيل سيارات، دراجات وموتوسيكلات.',
    listings: [
      { name: 'تكسي كنصفرة — أبو محمد', detail: 'خدمة 24 ساعة داخل وخارج البلدة', phone: '0933 887 665', verified: true },
      { name: 'ورشة الحسين لصيانة السيارات', detail: 'ميكانيك وكهرباء وحدادة', phone: ph },
    ] },
  { id: 'carpool', categoryId: 'transport', name: 'مشاركة الرحلات', icon: Users2, desc: 'رحلة إلى إدلب أو حلب، مقاعد متاحة، تقاسم التكلفة، حجز مقعد، إشعارات الرحلات.',
    listings: [{ name: 'رحلة إلى إدلب غداً 9 صباحاً', detail: '3 مقاعد متاحة — تقاسم تكلفة', phone: ph, tag: 'مقاعد متاحة' }] },
  // الزراعة
  { id: 'agri', categoryId: 'agri', name: 'الزراعة والثروة الحيوانية', icon: Tractor, desc: 'بذور وأسمدة، أدوات وآليات زراعية، بيطريون، أعلاف ومواشٍ، دواجن، نحل وعسل، شتول ونباتات، إرشاد زراعي.',
    listings: [
      { name: 'مكتب الزراعة الحديثة', detail: 'بذور وأسمدة ومستلزمات', phone: '0940 123 456', verified: true },
      { name: 'د. بيطري — أبو خليل', detail: 'معاينة وعلاج مواشٍ ودواجن', phone: '0955 889 900' },
    ] },
  // الخدمات
  { id: 'craftsmen', categoryId: 'services', name: 'الحرفيون', icon: Wrench, desc: 'كهربائيون، سباكون، نجارون، حدادون، دهّانون، بنّاؤون، مقاولون، صيانة أجهزة وهواتف وسيارات، صيانة منزلية عامة.',
    listings: [
      { name: 'أبو أحمد — كهربائي', detail: 'تأسيس وصيانة كهرباء منازل', phone: '0938 765 432', verified: true, tag: 'خبرة 15 سنة' },
      { name: 'سباكة وتدفئة العمري', detail: 'مياه وصحية وتدفئة مركزية', phone: '0944 321 098', verified: true },
    ] },
  { id: 'homeservices', categoryId: 'services', name: 'الخدمات المنزلية', icon: Home, desc: 'طاهي منزل، خادمة، مربية أطفال، مرافقة مسنين، رعاية مرضى، تمريض منزلي، توصيل أدوية.',
    listings: [{ name: 'تمريض منزلي — أ. ليلى', detail: 'إبر وقياس سكر وضغط وعناية', phone: '0933 654 987', tag: 'منزلي' }] },
  { id: 'childcare', categoryId: 'services', name: 'رعاية الأطفال', icon: Baby, desc: 'حضانات، مربيات معتمدات، طلب مربية منزلية، تسجيل في روضة، نشاطات أطفال، دروس خاصة، أندية صيفية.',
    listings: [{ name: 'حضانة براعم المستقبل', detail: 'أعمار 1-5 سنوات مع نشاطات', phone: ph, verified: true }] },
  { id: 'eldercare', categoryId: 'services', name: 'رعاية المسنين', icon: PersonStanding, desc: 'خدمات منزلية للمسنين، مرافق شخصي، تمريض، توصيل للعيادات، نشاطات اجتماعية.',
    listings: [{ name: 'مرافقة ورعاية مسنين', detail: 'مرافقة يومية ومواعيد عيادات', phone: ph }] },
  { id: 'pets', categoryId: 'services', name: 'الحيوانات الأليفة', icon: PawPrint, desc: 'بيع وشراء وتبنّي، بيطريون وعلاج بيطري، مستلزمات وطعام، فقدان حيوانات.',
    listings: [{ name: 'عيادة بيطرية متنقلة', detail: 'زيارات منزلية للحيوانات الأليفة', phone: ph }] },
  // المناسبات
  { id: 'socialevents', categoryId: 'events', name: 'المناسبات الاجتماعية', icon: PartyPopper, desc: 'قاعات أفراح، تصوير مناسبات، تنظيم حفلات، تجهيزات أعراس، بدلات عرسان، كوش أفراح، مطابخ وحلويات مناسبات، هدايا، خدمات تعازي ومقابر ونفقات دفن.',
    listings: [
      { name: 'قاعة الياسمين للأفراح', detail: 'سعة 300 شخص مع كوشة وتصوير', phone: '0930 222 888', verified: true },
      { name: 'استوديو اللحظات', detail: 'تصوير أفراح ومناسبات', phone: ph },
    ] },
  { id: 'personalevents', categoryId: 'events', name: 'المناسبات الشخصية', icon: Cake, desc: 'حفلات زفاف، أعياد ميلاد، تخرج، عقيقة، ختان، ذكرى زواج، تجمعات عائلية — تنظيم + دعوات إلكترونية.',
    listings: [{ name: 'منظمة حفلات فرح', detail: 'تنظيم كامل من الدعوة حتى الحفل', phone: ph }] },
  { id: 'invites', categoryId: 'events', name: 'الدعوات الإلكترونية', icon: Mail, desc: 'دعوة زفاف، دعوة عيد ميلاد، دعوة تخرج، تصاميم إسلامية وعصرية، تأكيد حضور RSVP، مشاركة عبر واتساب.',
    listings: [{ name: 'دعواتي — تصميم دعوات', detail: 'دعوات إلكترونية جاهزة خلال يوم', phone: ph, tag: 'جديد' }] },
  { id: 'wedding', categoryId: 'events', name: 'خدمات الزفاف', icon: Heart, desc: 'قاعات، مصورون، فيديوغراف، فستان عروس وبدلة عريس، ميكاج، كوافير، زفة، كوش، دعوات، حلويات، تسجيلات.',
    listings: [{ name: 'باقة الزفاف الكاملة', detail: 'قاعة + كوشة + تصوير + زفة', phone: ph, tag: 'باقة' }] },
  // المالية
  { id: 'finance', categoryId: 'finance', name: 'الخدمات المالية والقانونية', icon: CircleDollarSign, desc: 'حوالات مالية، شام كاش وMTN كاش، صرافة، حوالات بنكية، ذهب ومجوهرات، محاسبون ومدققون، محامون، كتاب عدل، مستشارون قانونيون، استشارات مالية وتأمين.',
    listings: [
      { name: 'صرافة البركة', detail: 'حوالات داخلية وخارجية وصرف عملات', phone: '0938 909 080', verified: true },
      { name: 'المحامي أ. خالد', detail: 'استشارات قانونية وعقود', phone: ph },
    ] },
  { id: 'rosca', categoryId: 'finance', name: 'الجمعيات المالية', icon: Wallet, desc: 'جمعيات ROSCA: تسجيل أعضاء، جدول الأدوار، إدارة الأموال، تنبيهات الدفع، سجل كامل.',
    listings: [{ name: 'جمعية أهالي الحي الغربي', detail: 'دور شهر 100$ — مقعدان متاحان', phone: ph, tag: 'مقاعد متاحة' }] },
  // الطوارئ والمجتمع
  { id: 'sos', categoryId: 'community', name: 'الطوارئ', icon: Siren, desc: 'زر الخطر SOS، إسعاف، دفاع مدني، شرطة، كهرباء طوارئ، مياه طوارئ، إغاثة طارئة، أرقام مهمة.',
    listings: [] },
  { id: 'ambulance', categoryId: 'community', name: 'الإسعاف والطوارئ', icon: Ambulance, desc: 'طلب إسعاف، طلب دفاع مدني، طلب شرطة، طلب كهرباء ومياه طوارئ، إشعار الجيران عند الطارئ.',
    listings: [] },
  { id: 'disasters', categoryId: 'community', name: 'الحالات الطارئة والكوارث', icon: LifeBuoy, desc: 'إرشادات السلامة، خطط إخلاء، مساعدات طارئة، تبرعات للكوارث، أرقام مهمة.',
    listings: [{ name: 'دليل السلامة والإخلاء', detail: 'إرشادات عند الزلازل والحرائق', phone: ph }] },
  { id: 'complaints', categoryId: 'community', name: 'الشكاوى والمقترحات', icon: MessageSquareWarning, desc: 'تقديم شكوى، اقتراح مبادرة، الإبلاغ عن مشكلة (حفر بالشوارع، عامود كهرباء مكسور)، متابعة حالة الشكوى، إشعارات.',
    listings: [{ name: 'قدّم شكوى أو اقتراح', detail: 'تصل مباشرة للجهة المختصة مع متابعة', phone: ph }] },
  { id: 'initiatives', categoryId: 'community', name: 'المبادرات المجتمعية', icon: Users2, desc: 'تنظيف الحي، تشجير، صيانة طرق، تبرع للجمعيات، حملات خيرية، مشاريع مشتركة.',
    listings: [{ name: 'حملة تشجير الحي الشمالي', detail: 'الجمعة القادمة — انضم إلينا', phone: ph, tag: 'مبادرة' }] },
  { id: 'charity', categoryId: 'community', name: 'الخير والتكافل', icon: HandHeart, desc: 'زكاة، صدقات، كفالة أيتام، مساعدات عاجلة، حملات موسمية، جمعيات خيرية.',
    listings: [
      { name: 'جمعية كنصفرة الخيرية', detail: 'كفالة أيتام ومساعدات شهرية', phone: '0933 100 900', verified: true },
      { name: 'سلة رمضان الغذائية', detail: 'تبرع بسلة لعائلة محتاجة', phone: ph, tag: 'موسمي' },
    ] },
  // المعلومات
  { id: 'news', categoryId: 'info', name: 'الأخبار والإعلام', icon: Newspaper, desc: 'أخبار كنصفرة، أخبار المنطقة، إذاعة محلية، إعلانات عامة، تعاميم رسمية.',
    listings: [
      { name: 'إذاعة كنصفرة المحلية', detail: 'بث يومي وبرامج منوعة', phone: ph },
      { name: 'تعميم: جدول تقنين الكهرباء', detail: 'الجدول الأسبوعي المحدّث', phone: ph, tag: 'تعميم' },
    ] },
  { id: 'public', categoryId: 'info', name: 'الخدمات العامة', icon: CloudSun, desc: 'طقس اليوم، أسعار الصرف، أسعار الذهب، أسعار المحروقات، أسعار الخضار والفواكه، مواقيت الصلاة، التقويم الهجري التفاعلي.',
    listings: [{ name: 'لوحة الأسعار اليومية', detail: 'صرف وذهب ومحروقات وخضار', phone: ph }] },
  { id: 'sports', categoryId: 'info', name: 'الرياضة والمسابقات', icon: Trophy, desc: 'أندية رياضية، ملاعب، صالات رياضية، مراكز شبابية، مسابقات رياضية، كشاف، سحوبات وجوائز.',
    listings: [
      { name: 'نادي كنصفرة الرياضي', detail: 'كرة قدم وطائرة — تسجيل مفتوح', phone: ph, verified: true },
      { name: 'ملعب البلدة', detail: 'حجز ساعات مسائية', phone: ph },
    ] },
]

export const sectionsByCategory = (catId: string) => sections.filter((s) => s.categoryId === catId)

/* ---------- منتجات السوق ---------- */
import { Shirt, Smartphone, Apple, Lamp, Watch, BookOpen, Sofa, Croissant } from 'lucide-react'
export const products: Product[] = [
  { id: 1, name: 'قميص رجالي قطني', shop: 'محل الأمانة', price: '12$', oldPrice: '18$', icon: Shirt, color: 'from-emerald-500 to-teal-600', verified: true, offer: 'خصم 33%' },
  { id: 2, name: 'هاتف Galaxy A15', shop: 'نور للأجهزة', price: '145$', icon: Smartphone, color: 'from-sky-500 to-indigo-600', verified: true },
  { id: 3, name: 'تفاح كنصفرة (كيلو)', shop: 'خضار البلد', price: '1.2$', icon: Apple, color: 'from-red-500 to-rose-600', offer: 'موسمي' },
  { id: 4, name: 'مصباح طوارئ LED', shop: 'كهربائيات السلام', price: '9$', oldPrice: '12$', icon: Lamp, color: 'from-amber-400 to-orange-500', offer: 'الأكثر مبيعاً' },
  { id: 5, name: 'ساعة يد كلاسيكية', shop: 'مجوهرات الفرات', price: '38$', icon: Watch, color: 'from-violet-500 to-purple-600', verified: true },
  { id: 6, name: 'كتاب قصص أطفال', shop: 'مكتبة المعرفة', price: '4$', icon: BookOpen, color: 'from-cyan-500 to-sky-600' },
  { id: 7, name: 'كنباية 3 مقاعد', shop: 'أثاث الديار', price: '260$', oldPrice: '310$', icon: Sofa, color: 'from-stone-500 to-stone-700', offer: 'توصيل مجاني' },
  { id: 8, name: 'معمول بالفستق (كيلو)', shop: 'حلويات أم محمد', price: '7$', icon: Croissant, color: 'from-yellow-500 to-amber-600', verified: true },
]

/* ---------- أرقام الطوارئ ---------- */
export const emergencyNumbers = [
  { name: 'الإسعاف', number: '110', icon: Ambulance, color: 'bg-red-500' },
  { name: 'الدفاع المدني', number: '113', icon: LifeBuoy, color: 'bg-orange-500' },
  { name: 'الشرطة', number: '112', icon: Siren, color: 'bg-sky-600' },
  { name: 'كهرباء طوارئ', number: '0930 400 100', icon: CloudSun, color: 'bg-yellow-500' },
  { name: 'مياه طوارئ', number: '0930 400 200', icon: Droplets, color: 'bg-cyan-500' },
  { name: 'إغاثة طارئة', number: '0930 400 300', icon: HandHeart, color: 'bg-emerald-600' },
]

export const bloodRequests = [
  { blood: 'O+', place: 'مشفى إدلب المركزي', when: 'قبل ساعة', urgent: true },
  { blood: 'A-', place: 'نقطة كنصفرة الطبية', when: 'قبل 3 ساعات', urgent: true },
  { blood: 'B+', place: 'مشفى إدلب المركزي', when: 'أمس', urgent: false },
]

/* ---------- شريط المعلومات ---------- */
export const infoItems = [
  { label: 'الطقس', value: '24° مشمس' },
  { label: 'دولار', value: '14,850 ل.س' },
  { label: 'ذهب 21', value: '1,150,000 ل.س' },
  { label: 'بنزين', value: '13,200 ل.س' },
  { label: 'صلاة الظهر', value: '12:20' },
  { label: 'صلاة العصر', value: '15:45' },
]

export const announcements = [
  'تعميم: جدول تقنين الكهرباء المحدّث لهذا الأسبوع متاح الآن في قسم الأخبار',
  'حملة تشجير الحي الشمالي الجمعة القادمة — المشاركة مفتوحة للجميع',
  'التسجيل في دورة التجويد مفتوح حتى نهاية الأسبوع',
]
