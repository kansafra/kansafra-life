import { X, Phone, BadgeCheck } from 'lucide-react'
import type { Section } from '@/data/content'

interface Props {
  section: Section | null
  onClose: () => void
}

export default function SectionSheet({ section, onClose }: Props) {
  if (!section) return null
  const Icon = section.icon
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-[hsl(var(--background))] rounded-t-3xl max-h-[85vh] overflow-y-auto animate-fade-up">
        <div className="sticky top-0 bg-[hsl(var(--background))] pt-3 pb-2 px-5 border-b border-[hsl(var(--border))]">
          <div className="w-10 h-1 rounded-full bg-slate-300 mx-auto mb-3" />
          <div className="flex items-start gap-3">
            <span className="w-11 h-11 rounded-2xl bg-[hsl(var(--primary))]/10 grid place-items-center shrink-0">
              <Icon className="w-6 h-6 text-[hsl(var(--primary))]" />
            </span>
            <div className="flex-1">
              <h3 className="font-black text-lg">{section.name}</h3>
              <p className="text-xs text-[hsl(var(--muted-foreground))] leading-5 mt-1">{section.desc}</p>
            </div>
            <button onClick={onClose} className="w-8 h-8 grid place-items-center rounded-full bg-white border border-[hsl(var(--border))]" aria-label="إغلاق">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="p-4 space-y-3">
          {section.listings.length === 0 && (
            <p className="text-center text-sm text-[hsl(var(--muted-foreground))] py-8">
              استخدم زر الطوارئ أسفل الشاشة للوصول السريع لهذه الخدمة
            </p>
          )}
          {section.listings.map((l, i) => (
            <div key={i} className="bg-white rounded-2xl border border-[hsl(var(--border))] p-4 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h4 className="font-bold text-sm">{l.name}</h4>
                  {l.verified && <BadgeCheck className="w-4 h-4 text-[hsl(var(--primary))]" />}
                  {l.tag && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[hsl(var(--accent))]/15 text-amber-700">
                      {l.tag}
                    </span>
                  )}
                </div>
                <p className="text-xs text-[hsl(var(--muted-foreground))] mt-1 leading-5">{l.detail}</p>
              </div>
              <a
                href={`tel:${l.phone.replace(/\s/g, '')}`}
                className="shrink-0 w-10 h-10 rounded-full bg-[hsl(var(--primary))] text-white grid place-items-center"
                aria-label={`اتصال بـ ${l.name}`}
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          ))}
          <p className="text-center text-[11px] text-[hsl(var(--muted-foreground))] pt-2 pb-4">
            بيانات تجريبية للعرض — النسخة الأولى من التطبيق
          </p>
        </div>
      </div>
    </div>
  )
}
