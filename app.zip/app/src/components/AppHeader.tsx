import { Bell, ShoppingCart } from 'lucide-react'

interface Props {
  cartCount: number
  onCartClick: () => void
}

export default function AppHeader({ cartCount, onCartClick }: Props) {
  return (
    <header className="sticky top-0 z-40 bg-[hsl(var(--background))]/90 backdrop-blur-md border-b border-[hsl(var(--border))]">
      <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
        <img src="/logo-mark.png" alt="كنصفرة لايف" className="w-10 h-10 object-contain animate-heartbeat" />
        <div className="flex-1 min-w-0">
          <h1 className="font-black text-lg leading-5 text-[hsl(var(--foreground))]">كنصفرة لايف</h1>
          <p className="text-[11px] text-[hsl(var(--muted-foreground))]">كل كنصفرة بجيبك</p>
        </div>
        <button
          onClick={onCartClick}
          className="relative w-10 h-10 rounded-full bg-white border border-[hsl(var(--border))] grid place-items-center"
          aria-label="السلة"
        >
          <ShoppingCart className="w-5 h-5 text-[hsl(var(--foreground))]" />
          {cartCount > 0 && (
            <span className="absolute -top-1 -left-1 w-5 h-5 rounded-full bg-[hsl(var(--primary))] text-white text-[10px] font-bold grid place-items-center">
              {cartCount}
            </span>
          )}
        </button>
        <button
          className="relative w-10 h-10 rounded-full bg-white border border-[hsl(var(--border))] grid place-items-center"
          aria-label="الإشعارات"
        >
          <Bell className="w-5 h-5 text-[hsl(var(--foreground))]" />
          <span className="absolute top-2 left-2.5 w-2 h-2 rounded-full bg-red-500" />
        </button>
      </div>
    </header>
  )
}
