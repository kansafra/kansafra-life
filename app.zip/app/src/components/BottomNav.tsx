import { Home, LayoutGrid, Store, User, Siren } from 'lucide-react'
import type { PageId } from '@/types'

interface Props {
  active: PageId
  onChange: (p: PageId) => void
}

const items: { id: PageId; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'الرئيسية', icon: Home },
  { id: 'categories', label: 'الأقسام', icon: LayoutGrid },
  { id: 'emergency', label: 'SOS', icon: Siren },
  { id: 'market', label: 'السوق', icon: Store },
  { id: 'profile', label: 'حسابي', icon: User },
]

export default function BottomNav({ active, onChange }: Props) {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 bg-white border-t border-[hsl(var(--border))] pb-safe">
      <div className="max-w-lg mx-auto grid grid-cols-5 relative">
        {items.map(({ id, label, icon: Icon }) => {
          if (id === 'emergency') {
            return (
              <button
                key={id}
                onClick={() => onChange(id)}
                className="relative flex flex-col items-center pt-1 pb-2"
                aria-label="الطوارئ"
              >
                <span
                  className={`absolute -top-6 w-14 h-14 rounded-full grid place-items-center text-white shadow-lg border-4 border-white transition-colors animate-sos ${
                    active === id ? 'bg-red-700' : 'bg-red-600'
                  }`}
                >
                  <Icon className="w-6 h-6" />
                </span>
                <span className="mt-9 text-[10px] font-bold text-red-600">طوارئ</span>
              </button>
            )
          }
          const isActive = active === id
          return (
            <button
              key={id}
              onClick={() => onChange(id)}
              className="flex flex-col items-center gap-0.5 py-2.5"
              aria-label={label}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'text-[hsl(var(--primary))]' : 'text-slate-400'}`} />
              <span className={`text-[10px] ${isActive ? 'font-bold text-[hsl(var(--primary))]' : 'text-slate-400'}`}>
                {label}
              </span>
            </button>
          )
        })}
      </div>
    </nav>
  )
}
