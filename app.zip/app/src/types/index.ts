export type PageId = 'home' | 'categories' | 'market' | 'emergency' | 'profile'
