import { useState } from 'react'
import AppHeader from '@/components/AppHeader'
import BottomNav from '@/components/BottomNav'
import SectionSheet from '@/components/SectionSheet'
import HomePage from '@/pages/HomePage'
import CategoriesPage from '@/pages/CategoriesPage'
import MarketPage from '@/pages/MarketPage'
import EmergencyPage from '@/pages/EmergencyPage'
import ProfilePage from '@/pages/ProfilePage'
import { products, type Section } from '@/data/content'
import type { PageId } from '@/types'
import { X, Trash2, ShoppingCart } from 'lucide-react'

export default function App() {
  const [page, setPage] = useState<PageId>('home')
  const [section, setSection] = useState<Section | null>(null)
  const [cart, setCart] = useState<number[]>([])
  const [cartOpen, setCartOpen] = useState(false)
  const [toast, setToast] = useState<string | null>(null)

  const addToCart = (id: number) => {
    setCart((c) => [...c, id])
    const p = products.find((x) => x.id === id)
    setToast(`أُضيف «${p?.name}» إلى السلة`)
    setTimeout(() => setToast(null), 1800)
  }

  const navigate = (p: PageId) => {
    setPage(p)
    window.scrollTo({ top: 0 })
  }

  const cartItems = cart.map((id) => products.find((p) => p.id === id)!).filter(Boolean)

  return (
    <div className="min-h-screen bg-[hsl(var(--background))]">
      <AppHeader cartCount={cart.length} onCartClick={() => setCartOpen(true)} />

      <main className="max-w-lg mx-auto pb-28">
        {page === 'home' && <HomePage onOpenSection={setSection} onNavigate={navigate} onAddToCart={addToCart} />}
        {page === 'categories' && <CategoriesPage onOpenSection={setSection} />}
        {page === 'market' && <MarketPage onAddToCart={addToCart} />}
        {page === 'emergency' && <EmergencyPage />}
        {page === 'profile' && <ProfilePage />}
      </main>

      <BottomNav active={page} onChange={navigate} />
      <SectionSheet section={section} onClose={() => setSection(null)} />

      {/* سلة المشتريات */}
      {cartOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center" role="dialog" aria-modal="true">
          <div className="absolute inset-0 bg-black/50" onClick={() => setCartOpen(false)} />
          <div className="relative w-full max-w-lg bg-[hsl(var(--background))] rounded-t-3xl max-h-[80vh] overflow-y-auto animate-fade-up">
            <div className="sticky top-0 bg-[hsl(var(--background))] pt-3 pb-3 px-5 border-b border-[hsl(var(--border))] flex items-center justify-between">
              <h3 className="font-black text-lg flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-[hsl(var(--primary))]" />
                سلة المشتريات
              </h3>
              <button onClick={() => setCartOpen(false)} className="w-8 h-8 grid place-items-center rounded-full bg-white border border-[hsl(var(--border))]" aria-label="إغلاق">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3">
              {cartItems.length === 0 && (
                <p className="text-center text-sm text-[hsl(var(--muted-foreground))] py-10">السلة فارغة — تصفح السوق وأضف منتجاتك</p>
              )}
              {cartItems.map((p, i) => {
                const Icon = p.icon
                return (
                  <div key={i} className="bg-white rounded-2xl border border-[hsl(var(--border))] p-3 flex items-center gap-3">
                    <span className={`w-12 h-12 rounded-xl bg-gradient-to-br ${p.color} grid place-items-center shrink-0`}>
                      <Icon className="w-6 h-6 text-white" />
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm truncate">{p.name}</p>
                      <p className="text-[11px] text-[hsl(var(--muted-foreground))]">{p.shop}</p>
                    </div>
                    <span className="font-black text-sm text-[hsl(var(--primary))]">{p.price}</span>
                    <button
                      onClick={() => setCart((c) => c.filter((_, idx) => idx !== i))}
                      className="w-8 h-8 grid place-items-center rounded-full text-red-500 hover:bg-red-50"
                      aria-label="حذف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )
              })}
              {cartItems.length > 0 && (
                <>
                  <button className="w-full h-12 rounded-2xl bg-[hsl(var(--primary))] text-white font-black text-sm">
                    إتمام الطلب — دفع عند الاستلام (COD)
                  </button>
                  <p className="text-center text-[11px] text-[hsl(var(--muted-foreground))]">يدعم أيضاً شام كاش وMTN كاش والتحويل المحلي</p>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* تنبيه الإضافة */}
      {toast && (
        <div className="fixed bottom-24 inset-x-0 z-50 flex justify-center px-4 pointer-events-none">
          <div className="bg-[#17203c] text-white text-xs font-bold px-4 py-2.5 rounded-full shadow-lg animate-fade-up">
            {toast}
          </div>
        </div>
      )}
    </div>
  )
}
